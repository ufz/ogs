% Analytical solution for the wellbore heat transport
% temperature of undistributed formation
T_d = 55;
% temperature of inlet fluid
T_i = 20;
% depth below surface
Z = 30;
% flow rate of fluid in wellbore, m3/s
q = 0.0002;
% density of fluid,unit kg/m3
rho_f = 1000;
% specific heat capacity of fluid in wellbore
c_p_f = 4190;
mu_f = 1.14e-3; % unit kg/m/s;
lambda_f = 0.59; % unit W/m/K
% density of geothermal reservoir
rho_re = 1800;
% specific heat capacity of geothermal reservoir
c_p_re = 1778;
% heat conductivity coefficient of geothermal reservoir
lambda_re = 2.78018;
% heat conductivity coefficient of grout and pipe
lambda_g = 0.73;
lambda_pi = 1.3;

% inner radius of pipe and wellbore
r_pi = 0.12913;
r_b = 0.14;

% thickness of the pipe
t_pi = 0.00587;

% operation time
t = 86400*30;

% convective heat transfer coefficient
% calculate the convective film resistance inside pipe
v = q/(pi*r_pi*r_pi);
% Reynolds number
Re = rho_f*v*(2*r_pi)/mu_f;
Pr = mu_f * c_p_f / lambda_f;
% Churchill correlation for friction factor;
f = 1/power(1/(sqrt(power(8/Re,10)+power(Re/36500,20)))+power(2.21*log(Re/7),10),1/5);
% Gnielinski correlation is used to estimate convective film coefficient;
Nu_Gl = (f/8*(Re-1000)*Pr)/(1+12.7*sqrt(f/8)*(power(Pr,2/3)-1));
Nu_lam = 4.364;
% evaluate Nusselt number; based on value of Re choose appropriate
% correlation
if Re < 2300
    Nu_p = Nu_lam;
else
    Nu_p = Nu_Gl;
end
h = lambda_f * Nu_p/ (2*r_pi) ; % unit: W/m2/K

U = 1 / ((r_pi + t_pi)/(r_pi * h) + (r_pi + t_pi) * (log((r_pi + t_pi)/r_pi)/lambda_pi + log(r_b/(r_pi + t_pi))/lambda_g));

fileID = fopen('T.txt','w');

for delta_t = 0:3600:t
    for delta_z = 0:1:Z
    %delta_z = Z;
t_D = lambda_re * delta_t / (rho_re * c_p_re * r_b * r_b);

if t_D > 1.5
    f_t = (0.4063 + 0.5 * log(t_D)) * (1 + 0.6 / t_D);
else
    f_t = 1.1281 * sqrt(t_D) * (1 - 0.3 * sqrt(t_D));
end

X = (q * rho_f * c_p_f) * (lambda_re + r_pi * U * f_t)/(2 * pi * r_pi * U * lambda_re);

T_o = T_d + (T_i - T_d) * exp(-delta_z / X);

disp(T_o)
figure(1)
plot(delta_t, T_o, 'r.')
title('Temperature over time')
hold on;

T=[delta_t, delta_z, T_o];
fprintf(fileID,'%12.8f %12.8f %12.8f\n',T)
    end
%T=[delta_t, T_o];
%fprintf(fileID,'%12.8f %12.8f\n',T)
end
fclose(fileID);
