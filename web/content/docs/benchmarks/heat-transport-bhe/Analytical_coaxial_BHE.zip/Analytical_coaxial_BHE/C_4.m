% function used to calculate the analytical solution
% of temperature distribution in an around Borehole 
% Heat Exchangers (BHE) proposed by Beier2014 
%
% Richard A. Beier (2014) Transient heat transfer in a 
% CXA borehole heat exchanger, 
% Geothermics 51: 470-482. 
% 
%
% Author: Chaofan Chen
% Email:  cchaofan1311(at)gmail(dot)com

% This function is according to Eq. (B.13)
function rt = C_4(s, N_s, N_g, N_12, H_g, H_f, kappa, A_D1, A_D2, r_Db)

rt = (-(N_s/s)-(1-delta_1(s,N_s,N_g,N_12,H_g,H_f,kappa,A_D1,A_D2,r_Db))*C_3(s, N_s, N_g, N_12, H_g, H_f, kappa, A_D1, A_D2, r_Db))/(1-delta_2(s,N_s,N_g,N_12,H_g,H_f,kappa,A_D1,A_D2,r_Db)); 