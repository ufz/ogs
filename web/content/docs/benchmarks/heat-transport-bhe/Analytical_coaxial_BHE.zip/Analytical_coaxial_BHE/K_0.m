% function used to calculate the analytical solution
% of temperature distribution in an around Borehole 
% Heat Exchangers (BHE) proposed by Beier2014 
%
% Richard A. Beier (2014) Transient heat transfer in a 
% U-tube borehole heat exchanger, 
% Applied Thermal Engineering 62: 256-266. 
% http://dx.doi.org/10.1016/j.applthermaleng.2013.09.014
%
% Author: Haibing Shao
% Email:  haibing(dot)shao(at)gmail(dot)com

% calculate the modified Bessel function 
% of the second kind with 0-order
function K = K_0(arg)

K = besselk(0,arg); 