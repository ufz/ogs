% This MATLAB script is used to calculate the steady-state solution of a
% heat-pipe problem semi-analytically. It is slightly modified after the
% original script provided in Huang et al. (2015).

% Y. Huang, O. Kolditz, and H. Shao. Extending the persistent primary
% variable algorithm to simulate non-isothermal two-phase two-component
% flow with phase change phenomena. Geothermal Energy 3 (1) (2015).
% http://dx.doi.org/10.1186/s40517-015-0030-8.

% Authors: Boyan Meng and Yonghui Huang
% Email: boyan107@gmail.com

clear;
M=10000;% devide the domain into M subdomains
a1=0;
b1=2.4;
h=(b1-a1)/M;% the width
i=1;
global K;
K=1e-12; % intrinsic permeability
global phi;% porosity
phi=0.4;
global eps;
eps=1e-8;
global rho_w;% The density of the water
rho_w=1000;
global rho_a;% The density of the air
rho_a=0.08;
global Mw;% Molar Mass of water
Mw=0.018016;
global Ma;%Molar Mass of air
Ma=0.02897;
global mu_w;% Viscosity of water 
mu_w=2.938e-4;
global mu_g_a;%Viscosity of gas air
mu_g_a=2.194e-5;
global mu_g_w;% Viscosity of the vapor water
mu_g_w=1.2e-5;
p0=101325;% Reference values, not IC
T0=100+273.15;
global lambda_dry;
global lambda_wet;
lambda_dry=0.582;%heat conductivity of dry rock
lambda_wet=1.14;%heat conductivity of saturated rock
global D;% Diffusion constant
D=2.6e-6;
global tau;
tau=0.5;% Tortousity
global R;
R=8.3144621;% universal gas constant
global h_wg;
h_wg=2258000;% latent heat of vaporization the unit 
%calculate the boudary condition of Temperature
T_bc=343;
pg_bc=101934; % pa
Swe_bc=0.96527;%
pc_bc=capillary_pressure( Swe_bc );
global q;
q=-100;
X_a_bc=1-p0/pg_bc*exp((1/T0-1/T_bc)*h_wg*Mw/R-pc_bc*Mw/rho_w/R/T_bc); % x^a_G
% calculate ODE system using Runge-Kutta 4th order method
Swe=zeros(M);
Swe(1)=Swe_bc;
T=zeros(M);
T(1)=T_bc;
pg=zeros(M);
pg(1)=pg_bc;
X_a=zeros(M);
X_a(1)=X_a_bc;
%---- construct the vector 
Za=[Swe_bc pg_bc X_a_bc T_bc]; 
Z=zeros(M+1,length(Za));
TT=zeros(1,M+1);
TT=a1:h:b1;
Z(1,:)=Za;
% here i needs to be determined by trial and error, basically i/M has to
% fall on the end of the two-phase zone
for i=1:6719
     %---------Runge-Kutta 4---------------
        k1=h*feval('F',TT(i),Z(i,:));% here F should be a string 
        k2=h*feval('F',TT(i)+h/2,Z(i,:)+k1/2);
        k3=h*feval('F',TT(i)+h/2,Z(i,:)+k2/2);
        k4=h*feval('F',TT(i),Z(i,:)+k3);
        Z(i+1,:)=Z(i,:)+(k1+2*k2+2*k3+k4)/6;     
end
