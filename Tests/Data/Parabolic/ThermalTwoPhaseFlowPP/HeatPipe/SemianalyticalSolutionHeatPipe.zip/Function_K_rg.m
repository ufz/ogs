% This MATLAB script is used to calculate the steady-state solution of a
% heat-pipe problem semi-analytically. It is slightly modified after the
% original script provided in Huang et al. (2015).

% Y. Huang, O. Kolditz, and H. Shao. Extending the persistent primary
% variable algorithm to simulate non-isothermal two-phase two-component
% flow with phase change phenomena. Geothermal Energy 3 (1) (2015).
% http://dx.doi.org/10.1186/s40517-015-0030-8.

% Authors: Boyan Meng and Yonghui Huang
% Email: boyan107@gmail.com

function [ K_rg ] = Function_K_rg( Swe )
%Input   - Swe is the water saturation
%Output  - K_rg is the relative permeability of the gas phase
% relative permeability of gas phase

K_rg=(1-Swe)^3;
end

