% This MATLAB script is used to calculate the steady-state solution of a
% heat-pipe problem semi-analytically. It is slightly modified after the
% original script provided in Huang et al. (2015).

% Y. Huang, O. Kolditz, and H. Shao. Extending the persistent primary
% variable algorithm to simulate non-isothermal two-phase two-component
% flow with phase change phenomena. Geothermal Energy 3 (1) (2015).
% http://dx.doi.org/10.1186/s40517-015-0030-8.

% Authors: Boyan Meng and Yonghui Huang
% Email: boyan107@gmail.com

function [ Z ] = F( T,Z )
% Input:  - T is the vector of steps(space)
%         - Z is initial condition 
% Output: - Z is the result matrix. each column refers to the 
%            variable saturation, pressure, molar fraction, Temperature, respectively.
global K;
global lambda_dry;
global lambda_wet;
global eps;
global R;
global mu_w;
global rho_w;
% global rho_a;
% global tau;
global phi;
global D;
global h_wg;
global Ma;
global Mw;
global q;
Swe=Z(1);
pg=Z(2);
X_a=Z(3);
T=Z(4);
D_pm=phi*(1-Swe)*D;%phi*(1-Swe)*D*tau;% diffusion coefficient 
lambda=lambda_dry+sqrt(Swe)*(lambda_wet-lambda_dry);% heat conductivity
pc=capillary_pressure( Swe);
dpcdswe=(capillary_pressure(Swe+eps)-capillary_pressure(Swe-eps))/(2*eps);
%--------The calculation of eta
K_rg=Function_K_rg(Swe);
K_rl=Function_K_rl(Swe);
mu_g=1.8e-5;
rho_g_a=Ma*X_a*pg/R/T;
rho_g_w=Mw*(1-X_a)*pg/R/T;
rho_g=rho_g_a+rho_g_w;
nu_g=mu_g/rho_g;
nu_w=mu_w/rho_w;
beta=nu_w/nu_g;
alpha=1+pc/rho_w/h_wg; %alpha=1+(pc-X_a*pg)/rho_w/h_wg;
xi=(1/K_rg)*(1+((rho_w*R*T)/pg/Mw)*(1/(1-X_a)))+beta/K_rl;
delta=rho_w*h_wg*h_wg*K*alpha/(lambda*nu_g*T);
zeta=((K*rho_w*R*T)/(Mw*rho_g*nu_g*D_pm))*(X_a/(1-X_a))*(pg*Mw/rho_w/R/T+1/(1-X_a));
eta=delta/(delta+xi+zeta);
% Constructing the four coupled differential equations
F1=-(1/(1-X_a)+beta*K_rg/K_rl)*eta*q*nu_g/K/h_wg/K_rg/dpcdswe;
F2=-(eta*q*nu_g/K/h_wg/K_rg)*(1/(1-X_a));
F3=eta*q*X_a/h_wg/D_pm/rho_g/(1-X_a);
F4=-q*(1-eta)/lambda;
Z=[F1,F2,F3,F4];

end

