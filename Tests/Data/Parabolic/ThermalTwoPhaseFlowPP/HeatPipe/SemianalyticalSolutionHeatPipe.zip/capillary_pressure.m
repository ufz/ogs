% This MATLAB script is used to calculate the steady-state solution of a
% heat-pipe problem semi-analytically. It is slightly modified after the
% original script provided in Huang et al. (2015).

% Y. Huang, O. Kolditz, and H. Shao. Extending the persistent primary
% variable algorithm to simulate non-isothermal two-phase two-component
% flow with phase change phenomena. Geothermal Energy 3 (1) (2015).
% http://dx.doi.org/10.1186/s40517-015-0030-8.

% Authors: Boyan Meng and Yonghui Huang
% Email: boyan107@gmail.com

function [ pc ] = capillary_pressure( Swe )
%Input   - Swe is the water saturation
%Output  - pc is the capillary pressure
gamma=0.05878;
global phi;
global K;
p1=sqrt(phi/K);
pc=p1*gamma*(1.417*(1-Swe)-2.120*(1-Swe)^2+1.263*(1-Swe)^3);

end

